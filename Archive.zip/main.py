from app.server import run


run()


