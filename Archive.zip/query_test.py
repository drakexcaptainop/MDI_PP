
import sqlite3
import time
import pandas as pd
import requests

conn = sqlite3.connect("example.db")

TABLE_NAME = 'products'

res = conn.execute( f'select * from {TABLE_NAME}' )

'''
Products
name varcahar
overview varchar
'''

names = []
overviews = []
while not( (row:=res.fetchone()) is None ):
    names.append( row[0] ) 
    overviews.append( row[1] ) 

print(names)
POST_PATH = 'http://localhost:8004/column'
print(requests.post( POST_PATH, json={
    "table_name": "products",
    "uid": None,
    "column_name": "name",
    "data": names
} ).status_code)

# print(requests.post( POST_PATH, json={
 #   "table_name": "products",
  #  "uid": [*range(len(names))],
   # "column_name": "overview",
    #"data": overviews
#} ).status_code)



